
export const PRIZES = [
  'Rp 10.000',
  'Rp 20.000',
  'Rp 50.000',
  'Rp 75.000',
  'Rp 100.000',
  'Rp 150.000',
  'Rp 200.000',
];

// IMPORTANT: Replace with the actual admin WhatsApp number
export const WHATSAPP_ADMIN_NUMBER = '6281234567890'; 

export const COLORS = [
  '#ef4444', // red-500
  '#f97316', // orange-500
  '#eab308', // yellow-500
  '#84cc16', // lime-500
  '#22c55e', // green-500
  '#3b82f6', // blue-500
  '#8b5cf6', // violet-500
];